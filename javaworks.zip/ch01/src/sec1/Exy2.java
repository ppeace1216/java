package sec1;

//기능 클래스 모델링
public class Exy2 {
	public void method1(){ //method1:메서드명
		System.out.println("하이~예제2!"); //실행문장 끝에 ;(세미콜론=컨티뉴) 
		
	}
}
